import { useState } from "react";
import "./App.css";
// import About from "./components/About";
import Navbar from "./components/Navbar";
import TextForm from "./components/TextForm";
import Alert from "./components/Alert";


function App() {
  const toggleMode = ()=>{
    if(mode === 'light'){
      setMode('dark');
      document.body.style.backgroundColor = 'grey';
      showAlert('Dark Mode Enabled','success');
    }else{
      setMode('light')
      document.body.style.backgroundColor = 'white';
      showAlert('Light Mode Enabled','success');
    }
 }

 const showAlert = (message,type)=>{
    setAlert ({
      msg : message,
      type : type
    })
 }
 const [mode, setMode] = useState('light')
 const [alert, setAlert] = useState(null)


  return (
    
    <>
      {/* <Navbar title="TextUtils" aboutTitle = "About TextUtils"/> */}
      {/* <Navbar></Navbar> */}
      <Navbar title="TextUtils" mode={mode} toggleMode = {toggleMode}/>
      <Alert alert = {alert} />
      <div className="container">
      <TextForm heading="Enter Your Text Here" mode={mode} showAlert = {showAlert}/>
      {/* <About title="BasXt"/> */}
      </div>
  </>
  );
}

export default App;
