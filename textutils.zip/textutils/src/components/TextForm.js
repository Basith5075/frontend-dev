import React, { useState } from "react";

// rfc -- shortcut for creatig the boiler plate code for
export default function TextForm(props) {
  // Event Handling done here, this code will execute when the Upper case button is clicked
  const handleUpClick = () => {
    // console.log("Upper case button clicked"+text);

    let newText = text.toUpperCase();

    setText(newText);
    props.showAlert("Converted to Upper Case !!","success");
    
  };
  const handleLoClick = () => {
    // console.log("Upper case button clicked"+text);

    let newText = text.toLowerCase();

    setText(newText);
    props.showAlert("Converted to Lower Case !!","success");
  };

  // This code will be executed when something is typed in the textArea
  const handleOnChange = (event) => {
    // console.log('handle onchange called')
    setText(event.target.value);
  };

  const handleClear = (event) => {
    let newText = ''
    setText(newText);
    props.showAlert("Cleared text !!","success");
  }

  const [text, setText] = useState(''); // Hooks used here
  return (
    <>
    
        <div className="container" style={{color:props.mode === 'light'?'black':'white'}}>
        <h1>{props.heading}</h1>
          <div className="mb-3">
            <textarea
              style = {{backgroundColor : props.mode === 'light'?'white':'grey',
              color:props.mode === 'light'?'black':'white'}}
              className="form-control my-3"
              value={text}
              onChange={handleOnChange}
              id="mytext"
              rows="8"
            ></textarea>
          </div>
          <button className="btn btn-primary mx-2" onClick={handleUpClick}>
            Convert to Upper Case
          </button>
          <button className="btn btn-primary mx-2" onClick={handleLoClick}>
            Convert to Lower Case
          </button>
          <button className="btn btn-primary mx-2" onClick={handleClear}>
            Clear
          </button>
        </div>
     
      <div className="container my-2" style={{color:props.mode === 'light'?'black':'white'}}>
        <h2>Your Text Summary </h2>
        <p> {text.split(" ").length} Words and {text.length} characters</p>
        <h2>Preview</h2>
        <p>{text.length ===0 ?'Please Write something above to preview here':text}</p>
      </div>
    </>
  );
}